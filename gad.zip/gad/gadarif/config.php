<?php


if($conn = mysqli_connect('localhost','root','','myproject')){
  //  echo"connect";
}else{
    echo"not ";
}

?>